from flask_wtf import FlaskForm
from wtforms import StringField,IntegerField,SubmitField


class AddForm(FlaskForm):

    Username = StringField('Enter The Username/MailId')
    Password = StringField('Enter The PASSWORD')
    Strength = StringField('zzzz')
    submit = SubmitField('Check Strength')
